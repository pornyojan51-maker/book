---
name: Ink & Indigo
colors:
  surface: '#f3faff'
  surface-dim: '#c7dde9'
  surface-bright: '#f3faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e6f6ff'
  surface-container: '#dbf1fe'
  surface-container-high: '#d5ecf8'
  surface-container-highest: '#cfe6f2'
  on-surface: '#071e27'
  on-surface-variant: '#454652'
  inverse-surface: '#1e333c'
  inverse-on-surface: '#dff4ff'
  outline: '#767683'
  outline-variant: '#c6c5d4'
  surface-tint: '#4c56af'
  primary: '#000666'
  on-primary: '#ffffff'
  primary-container: '#1a237e'
  on-primary-container: '#8690ee'
  inverse-primary: '#bdc2ff'
  secondary: '#5b5e68'
  on-secondary: '#ffffff'
  secondary-container: '#e0e2ee'
  on-secondary-container: '#61646e'
  tertiary: '#400004'
  on-tertiary: '#ffffff'
  tertiary-container: '#67000c'
  on-tertiary-container: '#ff6360'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e0e0ff'
  primary-fixed-dim: '#bdc2ff'
  on-primary-fixed: '#000767'
  on-primary-fixed-variant: '#343d96'
  secondary-fixed: '#e0e2ee'
  secondary-fixed-dim: '#c4c6d2'
  on-secondary-fixed: '#181b24'
  on-secondary-fixed-variant: '#434750'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ae'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930015'
  background: '#f3faff'
  on-background: '#071e27'
  surface-variant: '#cfe6f2'
typography:
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.4'
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.4'
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.5'
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.5'
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
The design system embodies a "Modern Corporate" aesthetic with a focus on editorial precision and cross-cultural clarity. It targets professional environments where information density must coexist with visual breathing room. The brand personality is reliable, systematic, and intellectually curious.

The style leverages **Minimalism** with a **Tonal Layering** approach. It avoids heavy ornamentation, instead using refined typography and a purposeful color palette to guide the user's focus. The interface should feel like a high-end digital publication—structured, calm, and authoritative.

## Colors
The palette is built on the "Ink & Indigo" concept. 

- **Primary (Indigo):** A deep, scholarly blue used for brand moments, primary actions, and active states. It provides a strong foundation of trust.
- **Secondary (Paper):** A very light, cool-tinted neutral used for subtle backgrounds and grouping elements without adding visual weight.
- **Tertiary (Accent):** A sharp, energetic red used sparingly for critical alerts or high-priority calls to action.
- **Neutral (Ink):** A slate grey used for secondary text and borders to maintain high legibility without the harshness of pure black.

Backgrounds should primarily use white (#FFFFFF) or the Secondary tint (#E8EAF6) to maintain a clean, open feel.

## Typography
This design system utilizes **IBM Plex Sans** (with full support for Thai characters) to achieve a technical yet humanistic feel. 

Thai typography requires specific attention to line height to accommodate ascending and descending diacritics without clipping. A minimum line-height of **1.6** is mandated for all body text to ensure maximum readability and a modern, airy feel. 

Headlines use a slightly tighter line-height (1.4 - 1.5) to maintain visual impact but should never go below 1.4. Letter spacing is kept neutral for body text but slightly increased for labels to improve legibility at smaller scales. All Thai text should be rendered with `line-break: loose` and `word-break: keep-all` where possible to maintain the integrity of Thai phrases.

## Layout & Spacing
The layout follows a **Fluid Grid** model based on an 8px base unit. 

- **Desktop:** 12-column grid with 24px gutters and 64px outside margins.
- **Tablet:** 8-column grid with 24px gutters and 32px outside margins.
- **Mobile:** 4-column grid with 16px gutters and 16px outside margins.

Spacing between functional groups should be generous (md or lg) to mirror the editorial aesthetic. Internal component spacing should rely on the `sm` (12px) and `md` (24px) units to create a clear hierarchy of information.

## Elevation & Depth
The design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows. 

Depth is communicated through color shifts:
1. **Level 0 (Base):** White (#FFFFFF).
2. **Level 1 (Cards/Surface):** Secondary Color (#E8EAF6) or White with a 1px border (#CFD8DC).
3. **Level 2 (Modals/Popovers):** White with an extra-diffused, 10% opacity shadow (Indigo tinted) to provide a soft lift.

Interactive elements use subtle background color transitions (e.g., shifting from White to a 5% Indigo tint on hover) to signal state changes without disrupting the flat, professional aesthetic.

## Shapes
The shape language is **Soft** and restrained. 

- Standard components (Buttons, Inputs) use a **0.25rem** (4px) radius.
- Large containers (Cards, Modals) use **0.5rem** (8px).
- This subtle rounding softens the technical nature of the typography while maintaining the professional, "square" structure of a corporate tool.

## Components

- **Buttons:** Solid Primary Indigo for main actions, using white text. Ghost buttons use Primary Indigo for text and a 1px Indigo border. Padding should be 12px vertical and 24px horizontal to accommodate Thai character height comfortably.
- **Input Fields:** 1px border using Neutral Slate. On focus, the border thickens to 2px Primary Indigo. Labels must always be visible above the field in `label-sm` style.
- **Cards:** White background with a subtle border (#CFD8DC) and 16px to 24px internal padding. Avoid shadows on cards unless they are draggable or floating.
- **Chips/Tags:** Secondary Indigo background with Primary Indigo text. Use `label-sm` typography.
- **Lists:** Clean dividers using 1px Secondary Indigo. Ensure 16px vertical padding between list items to prevent Thai text from feeling cramped.
- **Checkboxes/Radios:** Use Primary Indigo for the active state. Ensure the hit area is a minimum of 44x44px for accessibility.
- **Data Tables:** High-density but clear. Header rows use Secondary Indigo background with `label-md` bold text.